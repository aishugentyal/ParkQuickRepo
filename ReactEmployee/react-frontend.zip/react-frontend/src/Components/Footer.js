import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div>
        <footer className='footer'>
            <span className='text-muted'>All Rights Reserved 2020</span>

        </footer>
      </div>
    )
  }
}
